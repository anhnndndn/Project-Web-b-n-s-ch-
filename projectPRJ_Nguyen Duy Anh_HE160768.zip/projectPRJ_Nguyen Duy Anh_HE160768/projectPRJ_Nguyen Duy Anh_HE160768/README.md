# Nguyen Duy Anh 
---

## **Demo** 
---
> **Khách hàng**
1. Trang chủ 

![image](https://user-images.githubusercontent.com/53229758/172412202-94730a5e-7398-4174-a488-392495e33ec7.png)


2. Menu bar

![image](https://user-images.githubusercontent.com/53229758/172530538-872bbebf-c67b-47ac-aff8-7d3734b48c0a.png)

3. Sản phẩm

![image](https://user-images.githubusercontent.com/53229758/172412605-1f099276-ee92-449d-a63a-566de4306a76.png)

4. Chọn sản phẩm, loại hình, số lượng và đưa vào giỏ hàng

![image](https://user-images.githubusercontent.com/53229758/172412688-5ac0b85a-2bc2-4391-9b37-3a90ea826aa4.png)

5. Trong mục Checkout, điền thông tin cá nhân và tiến hành thanh toán 

![image](https://user-images.githubusercontent.com/53229758/172527754-9226e599-4ad0-4fbc-ad29-27557b20c931.png)

## **Author**
---
HMT